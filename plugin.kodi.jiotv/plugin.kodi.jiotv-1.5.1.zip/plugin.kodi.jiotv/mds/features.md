# Addon Features & Integration Guide

This document provides in-depth technical details and instructions for the major features of **JioTV Direct**.

---

## Community fork experience (v1.5.0+)

The home screen is organized for Android TV and D-pad navigation:

* **Favorites** stores stable channel and programme IDs and synchronizes the existing PVR favourites list.
* **Recently Watched** stores only reopenable, non-sensitive metadata. Use **Clear Recently Watched** in Settings to remove it.
* **Search** searches cached channel names/IDs and EPG programme metadata already seen by the TV Guide.
* **TV Guide** fetches one channel/day at a time with a 30-minute cache. Current, upcoming, and supported catch-up actions are shown without requiring a custom skin.

Playback quality is configured under **Settings > Playback**. `Auto` delegates
representation selection to InputStream Adaptive; fixed resolutions are
preferences and are only used when the stream exposes a suitable representation.
The add-on does not bypass authentication, DRM, licences, or subscription
controls.

---

## 🛡️ Favourite & Account Management (v1.1.5+)

The addon features a highly resilient backup system to manage your account and curated channels:
* **Resilient Account Backup**: Your login session is automatically backed up to a safe path that persists even if you uninstall or reinstall the addon.
* **Manage Favourites**: You can securely backup your chosen favourite channels, restore them across different devices, or share your curated list with others.
### Restore Shared Favourites
Quickly import a friend's shared favourites list directly into your Kodi setup.

### ⭐️ Port Favourites to TV Guide (v1.4.0_beta+)
You can port Kodi native favourites directly into the PVR TV Guide (IPTV Simple Client):
* **What it does**: Scans your Kodi `favourites.xml` and extracts all favourite channels belonging to **JioTV Direct** (`plugin.kodi.jiotv`), filtering out non-JioTV media/addons.
* **TV Guide Integration**: Automatically creates a dedicated **"Favourites"** channel group at the top of your TV Guide playlist (`jiotv.m3u`).
* **How to use**:
  1. Open **JioTV Direct** Add-on Settings.
  2. Go to **Favourites Management** (Category 3).
  3. Click **"Port Favourites to TV Guide"**.
  4. A popup confirmation will display the exact number of channels ported.
* **⚠️ Important Notice**: After clicking "Port Favourites to TV Guide", **you must restart Kodi** (or reload IPTV Simple Client in Kodi PVR Settings) once for the new **"Favourites"** group to reflect in your TV Guide grid.

### Coexistence with other JioTV Addons
Installing **JioTV Direct** (`plugin.kodi.jiotv`) does **not** replace or overwrite any existing JioTV addons (like `plugin.video.jiotv`). Both can be installed on the same system simultaneously.

### Favorites & Stream Compatibility
If you have favorites saved from **older or different** JioTV addons, they will **not work** with JioTV Direct.
* Old favorites point to different internal IDs and may use outdated streaming formats.
* To use JioTV Direct's high-quality **MPD streams**, you must **manually re-favorite** your channels from within the JioTV Direct addon menus.
* Only favorites created directly within this addon will benefit from the latest stream updates and performance improvements.

---

## 🌐 Network Stability & Mobile Hotspot Support (v1.2.0+)

Historically, Android TV devices connected via Mobile Hotspots inherently suffered from dual-stack DNS mapping issues (broken IPv6 routes), which caused JioTV streams (both Live and Catchup VOD) to timeout indefinitely or freeze the Kodi UI.

This addon contains a **Global Network Hotspot Optimizer**:
* **Automatic Auto-Patching**: Upon addon launch, it dynamically ensures Kodi's `advancedsettings.xml` instructs the internal C++ media players to bypass faulty Hotspot interfaces using IPv4.
* **Fail-Fast Mechanics**: The UI will no longer freeze if the network drops. Streams load seamlessly with heavily pooled non-blocking TLS sessions.
*(You will be notified to restart Kodi once the patch is applied on first launch)*

---

## 📹 Video On Demand (VOD) / Catch-up Feature

This add-on supports Video On Demand (VOD) and catch-up TV functionality for compatible channels.

### VOD Support Details
* **Channel Availability**: Not all TV channels support VOD content. The add-on automatically detects and displays VOD-capable channels.
* **Channel Organization**: VOD-enabled channels are sorted and organized exclusively by language categories (not by genre or other groupings).
* **Content Organization**: After selecting a channel from the VOD menu, available programs are organized chronologically by date in folders (Today, 1 Day Ago, 2 Days Ago, etc.), with the most recent content displayed first within each date folder.
* **Empty Content Warning**: Some channels may appear VOD-capable but deliver no actual content, resulting in empty date folders. This is a limitation of the service provider's implementation.
* **Content Accuracy**: VOD content may not start and end at the exact timestamp of the intended program, as this is limited by the service provider's implementation.
* **Ad Handling**: The add-on actively blocks advertisements on VOD content and loads the main program content.
* **Video Quality**: VOD content may initially load in lower quality and doesn't always support adaptive streaming. If needed:
  * Manually select video quality in the add-on settings.
  * Reopen VOD content multiple times until it loads in the desired quality.

### Accessing VOD Content
1. Navigate to any VOD-capable channel.
2. Select the channel to view available date folders (Today, 1 Day Ago, etc.).
3. Choose a date folder to see available VOD programs.
4. Select a program to start playback.

---

## 📅 EPG (Electronic Program Guide) Setup

If you are using the PVR functionality (via IPTV Simple Client) and the program guide is missing, follow these steps:

1. **Automatic Setup (Recommended)**: 
   - Open **JioTV Direct** addon.
   - Go to **Settings** > **Setup** category.
   - Click on **PVR Setup** (Label 33003). This will automatically configure `pvr.iptvsimple` with the latest EPG and playlist.
2. **Manual Configuration**:
   - If you want to use a custom EPG source, go to Addon **Settings** > **Setup** and find **EPG Source**.
   - You can paste any valid XMLTV URL (e.g., `https://raw.githubusercontent.com/mitthu786/tvepg/main/jiotv/epg.xml.gz`).
   - After changing the source, run **PVR Setup** again or restart Kodi.
3. **Troubleshooting**: If the guide still doesn't show up, ensure that "IPTV Simple Client" is enabled in your PVR addons and verify the "M3U Playlist Path" is pointing to the local file generated by this addon.

> The **TV Guide (EPG Grid)** option is primarily for viewing schedules and playing **Live Channels**. It cannot be used to browse or play the full **VOD/Catch-up** library. To play VOD programs or past broadcasts (Catch-up), please use the **"Video on Demand"** menu within the JioTV Direct addon.

---

## 📺 Extra Channels Integration & M3U Guide

This addon supports adding custom live video streams (HLS/DASH) directly into the Kodi interface and PVR system via the **Extra Channels** feature. It preloads a working template with 2 high-quality demo streams (Red Bull TV and Big Buck Bunny DASH) that can be easily customized.

### 🛠️ Exporting, Modifying, and Importing Playlist Template

1. **Export the M3U Template**:
   - Navigate to the **JioTV Direct** Add-on settings.
   - Go to the **Setup** category.
   - Scroll down to the **Extra Channels** group and click **Export Extra Channels Template (.m3u)**.
   - Select an easily accessible directory on your local device/storage. This saves `extra_channels_template.m3u`.

2. **Modify the M3U File**:
   - Open the exported `extra_channels_template.m3u` file on your device/PC using any text editor (such as Notepad, TextEdit, VS Code, etc.).
   - You can add your own custom streams by following the formatting guidelines below.

3. **Import the Playlist**:
   - Go back to Add-on settings > **Setup** > **Extra Channels**.
   - Click **Import Extra Channels (.m3u, .json, .xml)**.
   - Browse and select your modified M3U file.
   - The addon will automatically validate the format and show a success dialog upon successful import.

4. **Kodi Refresh / Restart**:
   - After a successful import, **please completely restart Kodi** or reload the add-on. This ensures that the background Simple IPTV PVR client playlist and Kodi's UI menus completely refresh and register the updated channels.

### ⚠️ Critical Notes & Guidelines for Extra Channels

> [!WARNING]
> **Absolute Replacement (Not Incremental)**: When you import an M3U file, it **completely wipes out and clears any existing extra channels** in the addon's memory. The import is an absolute replacement, not an incremental update.

> [!IMPORTANT]
> **Token Expiration & Link Renewal**: Many IPTV or stream links generated from third-party players contain time-limited Akamai CDN security tokens (e.g., `st=...~exp=...`). These links will naturally stop playing once their security token expires. **You must manually update and re-import your M3U playlist with renewed links.** We do not provide auto-renewal or generation of these tokens.

> [!CAUTION]
> **Disclaimer on Streams & Support**: We are **not responsible** for renewing M3U streams, generating playlists, maintaining external link lifetime, or any feature requests related to the playlist content beyond the core importer/player features implemented now. What has been provided so far is generous enough.

### 📝 M3U Line Item Syntax & Reference

An M3U playlist consists of a `#EXTM3U` header followed by channel listings. Each channel listing has two parts: metadata lines (beginning with `#EXTINF:` and `#KODIPROP:`) and the stream URL line.

#### 1. Basic HLS Stream
```m3u
#EXTINF:-1 tvg-id="RedBullTV" tvg-name="Red Bull TV" group-title="Sports" tvg-language="English" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/b/b2/Red_Bull_TV_logo.svg",Red Bull TV
https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8
```

#### 2. DASH Stream with ClearKey DRM
```m3u
#EXTINF:-1 tvg-id="BigBuckBunny" tvg-name="Big Buck Bunny DASH" group-title="Movies" tvg-language="English" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/c/c5/Big_Buck_Bunny_Main_Poster.jpg",Big Buck Bunny DASH
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=100b6c20b660447e96da3bf3ebe1531a:100b6c20b660447e96da3bf3ebe1531a
https://dash.akamaized.net/akamai/bbb_30fps/bbb_30fps.mpd
```

#### 3. Stream with Custom User-Agent and Headers
Custom HTTP headers (like `User-Agent` or `Referer`) can be appended to the stream URL using a pipe (`|`) character and URL-encoded query parameters.
```m3u
#EXTINF:-1 tvg-id="CustomStream" tvg-name="Custom Stream" group-title="Entertainment"
https://example.com/live.m3u8|User-Agent=Mozilla/5.0&Referer=https://example.com/
```

#### Parameter Breakdown:
* **`tvg-id`**: Unique identifier for the channel. Essential for mapping EPG.
* **`tvg-name`**: Readable name of the channel.
* **`group-title`**: Group or category name under which the channel will be categorized in Kodi UI.
* **`tvg-logo`**: URL to the channel logo image.
* **`tvg-language`**: Primary audio language of the channel.
* **`#KODIPROP:inputstream.adaptive.license_type`**: DRM licensing standard (use `org.w3.clearkey` for ClearKey, `com.widevine.alpha` for Widevine).
* **`#KODIPROP:inputstream.adaptive.license_key`**: DRM decryption key mapping (e.g. `KID:KEY` string).
